<?php 
return [
  'failed' => 'These credentials do not match our records.',
  'general_error' => 'You do not have access to do that.',
  'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
  'unknown' => 'An unknown error occurred',
];