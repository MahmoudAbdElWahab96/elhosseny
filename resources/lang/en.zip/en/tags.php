<?php
return [
'name'=>'Tag Name',
'tags'=>'Tags',
'tag'=>'Tag',
'new'=>'New Tag',
'color'=>'Tag Color',
'select'=>'Select Tag...',
'new_status'=>'New Status',
'tag_status'=>'Status & Tags',
];
