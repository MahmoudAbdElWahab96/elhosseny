<?php
return [
'warehouse'=>'Warehouse',
'warehouse_default'=>'Default Warehouse',
'warehouses'=>'Warehouses',
'title'=>'WareHouse name',
'extra'=>'WareHouse Description',
'valid_enter'=>'Please select a valid warehouse!',
];
