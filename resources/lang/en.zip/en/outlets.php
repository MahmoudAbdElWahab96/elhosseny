<?php
return [
    'outlets'=>'Business Outlets',
    'new_outlet'=>'New Outlet',
    'edit_outlet'=>'Edit Outlet',
    'delete_warning'=>'It will delete your all business data of selected outlet',
    'default_invoice_status'=>'Default invoice status',
     'pending_to_due'=>'Pending to due',
     'due_to_overdue'=>'Due to overdue',
    'auto_debit_transaction'=>'Auto Debit transaction',
    'remote_image'=>'Remote Images',
    'remote_image_info'=>'You can to append an extra column with image URL to import the images (14th col)'
];
