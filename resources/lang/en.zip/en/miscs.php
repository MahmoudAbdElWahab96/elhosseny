<?php
return [
'name'=>'Name',
'color'=>'Colour',
'section'=>'Section',
'miscs'=>'Tags & Statuses',
'misc'=>'Tag & Status',
];
