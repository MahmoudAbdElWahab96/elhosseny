<?php
return [
    'social_media'=>'Social Media',
    'features'=>'Features',
        'services'=>'Services',
];
