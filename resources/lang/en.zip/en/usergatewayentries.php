<?php
return [
'gateway'=>'Gateway',
'enable'=>'Enable',
'key1'=>'Key 1',
'key2'=>'Key 2',
'currency'=>'Currency Code',
'dev_mode'=>'Developer mode',
'surcharge'=>'Surcharge %',
'extra'=>'Other',
'usergatewayentries'=>'Payment Gateways',
'usergatewayentry'=>'Payment Gateway',
'surcharge_applicable'=>'Payment Gateway Surcharge Applicable to the total amount',
];
