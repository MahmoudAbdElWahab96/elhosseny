<?php
return [
'management'=>'Suppliers Management',
'suppliers'=>'Suppliers',
'supplier'=>'Supplier',
'valid_enter'=>'Please select a valid supplier!',
];
