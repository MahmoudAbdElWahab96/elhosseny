<?php
return [
'delivery'=>'Delivery',
];
