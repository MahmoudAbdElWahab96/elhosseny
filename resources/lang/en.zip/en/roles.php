<?php
return [
'administrator'=>'Administrator',
'user'=>'User',
];
