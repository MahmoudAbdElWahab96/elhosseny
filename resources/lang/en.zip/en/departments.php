<?php
return [
'name'=>'Name',
'note'=>'Note',
'departments'=>'Departments',
'department'=>'Department',
];
