<?php
return [
    'Desc_en' => 'Tax in Arabic',
    'Desc_ar' => 'Tax in English',
    'code' => 'Tax Code',
];
