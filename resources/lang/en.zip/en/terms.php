<?php
return [
'title'=>'Title',
'type'=>'Module',
'terms'=>'Terms',
'term'=>'Term',
'required'=>'Please create and select a payment term!',
];
