<?php
return [
'title'=>'Category',
'extra'=>'Description',
'sub_category'=>'Sub Category',
'sub_categories'=>'Sub Categories',
'total_products'=>'Total Products',
'total_worth'=>'Total Worth',
'c_type'=>'Category Type',
'rel_id'=>'Parent Category',
'parent'=>'Parent',
'child'=>'Child',
'productcategories'=>'Product Categories',
'valid_enter'=>'Please select a valid Product Category!',
];
