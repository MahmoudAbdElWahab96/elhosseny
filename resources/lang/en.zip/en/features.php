<?php
return [
'pos'=>'POS',
'sales'=>'Sales',
'stock'=>'Stock Manager',
'crm'=>'CRM',
'project_tasks'=>'Project & Tasks',
'project_management'=>'Project Management',
'tasks_management'=>'Tasks Management',
'promo'=>'Promo Manager',
'misc'=>'Miscellaneous',
'calendar'=>'Calendar',
'reports'=>'Data & Reports',
'import'=>'Import Data',
'export'=>'Export Data',
'transactions'=>'Transactions Manager',
'small'=>'Small Team - 3 Users',
'mid'=>'Mid Team - 10 Users',
'big'=>'Big Team - Unlimited Users',
'hrm'=>'HRM',
    'users'=>'Users'
];
