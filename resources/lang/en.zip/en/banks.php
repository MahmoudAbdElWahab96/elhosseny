<?php
return [
'name'=>'Account name',
'bank'=>'Bank',
'number'=>'Bank Account Number',
'code'=>'Account Code',
'note'=>'Note',
'address'=>'Branch Address',
'branch'=>'Branch',
'enable'=>'Enable',
'banks'=>'Bank Accounts',
'payable_accounts'=>'Payable Accounts',
];
