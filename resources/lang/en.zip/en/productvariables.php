<?php
return [
'name'=>'Name Arabic',
'name_en'=>'Name English',
'code'=>'Code',
'type'=>'Type',
'val'=>'Value',
'rid'=>'Related to',
'unit_default'=>'Default Unit',
'productvariables'=>'Product Unit Variables',
'productvariable'=>'Product Unit variable',
'standard_type'=>'Standard Type - Single Unit',
'multiple_type'=>'Multiple Type - Multiple Unit',
];
