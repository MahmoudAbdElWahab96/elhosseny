<?php
return [
'title'=>'Name',
'summary'=>'Summary',
'disc_rate'=>'Group Discount rate',
'members'=>'Members',
'group_message'=>'Send group message',
];
