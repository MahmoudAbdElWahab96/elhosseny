<?php
return [
    'sales_channel'=>'Market Channel',
     'sales_channels'=>'Market Channels',
     'sales_channel_statement'=>'Market Channel Statement',
     'new_sales_channel'=>'New Market Channel',
      'edit_sales_channel'=>'Edit Market Channel',
    'channel_name'=>'Channel Name',
    'sales_channel_settings'=>'Manage your Market Channel settings here. ',
    'sales'=>'Sales',
    'purchase'=>'Purchase',
     'pending_to_due'=>'Pending to due',
     'due_to_overdue'=>'Due to overdue',
    'auto_debit_transaction'=>'Auto Debit transaction',
    'name' => 'Name',
    'created_at' => 'Created At'
];
