<?php
return [
'home'=>'Home',
'plans'=>'Plans',
'blog'=>'Blog',
'about'=>'About',
'contact'=>'Contact Us',
'register_now'=>'Register Now',
'pricing_plans'=>'Our pricing plans',
'sign_up'=>'Sign Up',
'subscribe'=>'Subscribe',
'renew'=>'Renew Plan',
'subscribe_exist'=>'You have already subscribed this plan!',
'make_payment'=>'Make Payment to confirm the subscription',
];
