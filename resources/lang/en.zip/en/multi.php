<?php
/*SAAS USERS*/
return [
    'companies'=>'Manage Companies',
];
