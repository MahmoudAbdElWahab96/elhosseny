<?php
return [
'module_id'=>'Module',
'field_type'=>'Field Type',
'name'=>'Name',
'placeholder'=>'Placeholder',
'default_data'=>'Default Data',
'field_view'=>'Field View',
'customfields'=>'Custom fields',
'customfield'=>'Custom field',
'text'=>'Text',
'public'=>'Public',
'private'=>'Private',
];
