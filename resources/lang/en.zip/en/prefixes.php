<?php
return [
'class'=>'class',
'module'=>'Module',
'value'=>'Value',
'note'=>'Note',
'prefixes'=>'Prefixes',
'prefix'=>'Prefix',
'invoice'=>'Invoice',
'delivery_note'=>'Delivery Note',
'proforma_invoice'=>'Proforma Invoice',
'payment_receipt'=>'Payment Receipt',
'quotes'=>'Quotes',
'subscriptions'=>'Subscriptions',
'credit_note'=>'Credit Note',
'stock_return'=>'Stock Returns',
'purchase_order'=>'Purchase Order',
'POS'=>'POS Point Of Sale',
];
