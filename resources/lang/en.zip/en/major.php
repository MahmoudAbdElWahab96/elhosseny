<?php
return [
'address_1'=>'Address 1',
'address_2'=>'Address 2',
'city'=>'City',
'state'=>'State',
'country'=>'Country',
'postal'=>'Postal',
'company'=>'Company',
'tax_id'=>'TAX ID',
'contact'=>'Contact',
'price'=>'Price',
];
