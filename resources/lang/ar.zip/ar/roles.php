<?php
return [
'administrator'=>'مدير',
'user'=>'مستخدم',
];
