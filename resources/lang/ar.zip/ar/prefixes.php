<?php
return [
'class'=>'صف دراسي',
'module'=>'وحدة',
'value'=>'القيمة',
'note'=>'ملحوظة',
'prefixes'=>'البادئات',
'prefix'=>'اختصار',
'invoice'=>'فاتورة',
'delivery_note'=>'مذكرة تسليم',
'proforma_invoice'=>'الفاتورة الأولية',
'payment_receipt'=>'إيصال الدفع',
'quotes'=>'يقتبس',
'subscriptions'=>'الاشتراكات',
'credit_note'=>'اشعار دائن',
'stock_return'=>'إرجاع المخزون',
'purchase_order'=>'أمر شراء',
'POS'=>'نقاط البيع',
];
