<?php
return [
'title'=>'الفئة',
'extra'=>'وصف',
'sub_category'=>'تصنيف فرعي',
'sub_categories'=>'الفئات الفرعية',
'total_products'=>'إجمالي المنتجات',
'total_worth'=>'إجمالي القيمة',
'c_type'=>'نوع الفئة',
'rel_id'=>'القسم الرئيسي',
'parent'=>'الرئيسي',
'child'=>'الفرعي',
'productcategories'=>'فئات المنتجات',
'valid_enter'=>'يرجى تحديد فئة منتج صالحة!',
];
