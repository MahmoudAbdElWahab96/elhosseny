<?php
return [
'management'=>'طلبات الشراء',
'tid'=>'رقم طلب الشراء',
'invoicedate'=>'تاريخ الطلبات',
'invoiceduedate'=>'تاريخ تأكيد الطلبات',
'search_supplier'=>'ابحث عن المورد',
'supplier_details'=>'تفاصيل المورد',
'supplier_search'=>'أدخل اسم المورد أو رقم الهاتف المحمول للبحث',
'add_supplier'=>'إضافة مورد',
'properties'=>'الخصائص',
'bill_from'=>'فاتورة من',
'payment_for_order'=>'الدفع لأمر الشراء',
'purchaseorders'=>'طلبات الشراء',
'purchaseorder'=>'أمر شراء',
];
