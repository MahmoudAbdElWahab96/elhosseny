<?php
return [
'delivery'=>'دليفرى',
];
