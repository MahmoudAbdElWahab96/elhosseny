<?php
return [
'title'=>'اسم',
'summary'=>'ملخص',
'disc_rate'=>'معدل خصم المجموعة',
'members'=>'أفراد',
'group_message'=>'إرسال رسالة جماعية',
];
