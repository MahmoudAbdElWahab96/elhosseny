<?php
return [
'module_id'=>'وحدة',
'field_type'=>'نوع الحقل',
'name'=>'اسم',
'placeholder'=>'عنصر نائب',
'default_data'=>'البيانات الافتراضية',
'field_view'=>'عرض الحقل',
'customfields'=>'الحقول المخصصة',
'customfield'=>'حقل مخصص',
'text'=>'نص',
'public'=>'عامة',
'private'=>'نشر',
];
