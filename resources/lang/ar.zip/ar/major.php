<?php
return [
'address_1'=>'العنوان 1',
'address_2'=>'العنوان 2',
'city'=>'مدينة',
'state'=>'حالة',
'country'=>'بلد',
'postal'=>'بريدي',
'company'=>'شركة',
'tax_id'=>'الرقم الضريبي',
'contact'=>'اتصل',
'price'=>'السعر',
];
