<?php
return [
    'sales_channel'=>'قناه السوق',
     'sales_channels'=>'قنوات السوق',
     'sales_channel_statement'=>'حاله قناه السوق',
     'new_sales_channel'=>'انشاء قناه سوق جديده',
      'edit_sales_channel'=>'تعديل قناه سوق',
    'channel_name'=>'اسم القناه',
    'sales_channel_settings'=>'التحكم في اعدادات قناه السوق من هنا. ',
    'sales'=>'Sales',
    'purchase'=>'Purchase',
     'pending_to_due'=>'Pending to due',
     'due_to_overdue'=>'Due to overdue',
    'auto_debit_transaction'=>'Auto Debit transaction',
    'name' => 'الاسم',
    'created_at' => 'انشاء في '
];
