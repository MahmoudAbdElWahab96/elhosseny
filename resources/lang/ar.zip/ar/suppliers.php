<?php
return [
'management'=>'إدارة الموردين',
'suppliers'=>'الموردون',
'supplier'=>'المورد',
'valid_enter'=>'الرجاء تحديد مورد صالح!',
];
