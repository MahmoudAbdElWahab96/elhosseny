<?php
return [
'previous'=>'" السابق',
'next'=>'التالى "',
];
