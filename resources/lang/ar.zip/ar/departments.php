<?php
return [
'name'=>'اسم',
'note'=>'ملحوظة',
'departments'=>'الأقسام',
'department'=>'قسم',
];
