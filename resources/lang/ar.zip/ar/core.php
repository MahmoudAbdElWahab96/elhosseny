<?php
return [
'home'=>'الصفحة الرئيسية',
'plans'=>'الخطط',
'blog'=>'مدونة',
'about'=>'حول',
'contact'=>'اتصل',
'register_now'=>'سجل الان',
'pricing_plans'=>'خطط التسعير لدينا',
'sign_up'=>'سجل',
'subscribe'=>'الإشتراك',
'renew'=>'تجديد الخطة',
'subscribe_exist'=>'لقد اشتركت بالفعل في هذه الخطة!',
'make_payment'=>'قم بالدفع لتأكيد الاشتراك',
];
