<?php
return [
'warehouse'=>'مستودع',
'warehouse_default'=>'المستودع الافتراضي',
'warehouses'=>'مستودع',
'title'=>'اسم WareHouse',
'extra'=>'وصف WareHouse',
'valid_enter'=>'الرجاء تحديد مستودع صالح!',
];
