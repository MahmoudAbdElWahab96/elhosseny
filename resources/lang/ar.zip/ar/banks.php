<?php
return [
'name'=>'أسم الحساب',
'bank'=>'مصرف',
'number'=>'رقم الحساب المصرفي',
'code'=>'رمز الحساب',
'note'=>'ملحوظة',
'address'=>'عنوان فرع',
'branch'=>'فرع',
'enable'=>'تنشيط',
'banks'=>'حسابات بنكية',
'payable_accounts'=>'حسابات الدفع',
];
