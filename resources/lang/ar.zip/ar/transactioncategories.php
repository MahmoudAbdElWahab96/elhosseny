<?php
return [
'name'=>'اسم',
'transactioncategories'=>'فئات الحركات',
'transactioncategory'=>'فئة الحركة',
'valid_enter'=>'يرجى تحديد فئة حركة صالحة!',
];
