<?php
return [
    'default_invoice' => 'الفاتورة الافتراضية ',
    'invoice' => 'الفاتورة العادية ',
    'tax_invoice' => 'الفاتورة الضريبية ',
    'goal_settings'=>'اهداف الاعمال',

];
