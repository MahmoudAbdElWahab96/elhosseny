<?php
return [
'gateway'=>'بوابة',
'enable'=>'ممكن',
'key1'=>'المفتاح 1',
'key2'=>'المفتاح 2',
'currency'=>'رمز العملة',
'dev_mode'=>'وضع المطور',
'surcharge'=>'التكلفة الإضافية٪',
'extra'=>'آخر',
'usergatewayentries'=>'بوابات الدفع',
'usergatewayentry'=>'بوابة الدفع',
'surcharge_applicable'=>'تطبق رسوم بوابة الدفع على المبلغ الإجمالي',
];
