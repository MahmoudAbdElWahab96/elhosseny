<div class="modal fade" id="pos_print" role="dialog">
    <div class="modal-dialog modal-md">
        <div class="modal-content align-items-center">
            <div class="modal-body border_no_print" id="print_section">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" onclick="print_it();">{{trans('general.print')}}</button>
                <button type="button" class="btn btn-light"
                        data-dismiss="modal">{{trans('general.close')}}</button>
            </div>
        </div>
    </div>
</div>